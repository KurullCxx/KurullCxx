module.exports = {
    // --- TELEGRAM SETTINGS ---
    botToken: "8272703358:AAFB3gMlqlMT0kgVbWks26ePqstykCPquGw",
    ownerId: 6242915218,
    ownerName: "rizaldev",
    ownerWa: "6283119115977",
    ownerUser: "@rizeldev",
    grubName: "rizaldef", // isi tanpa @ dan https://t.me/
    channelName: "rizaldep", // isi tanpa @ 
    botName: "rizaldev auto order",
    startPhoto: "https://files.catbox.moe/r2mzcw.jpg",
    startAudio: "https://files.catbox.moe/q5nbev.mp3",
    startAudioCaption: "https://t.me/testirizel/250",
    testimoniChannel: "@testirizel",
    
    // --- Nokos Setting ( Rumah Otp )
    RUMAHOTP: "otp_xqCqoXGLPLekEkRj",
    UNTUNG_NOKOS: 700,
    UNTUNG_DEPOSIT: 700,
    ppthumb: "https://files.catbox.moe/r2mzcw.jpg",
    
    // --- Suntik Sosmed Setting ( FayuPedia )
    smm: {
        apiId: '181349', 
        apiKey: 'helhac-qwmk5e-lwyejo-ise1mr-7ctcjf', 
        baseUrl: 'https://fayupedia.id/api/order' 
    },

    // --- PAYMENT ORKUT --
    payment: {
        apikey: "rizaldev",
        username: "tokofaa",
        token: ""
    },

    // --- PAYMENT ATLANTIC ---
    ApikeyAtlantic: "apikey atlantic mu",
    wd_balance: {
        bank_code: "DANA", // DANA, BCA, BRI, dll
        destination_number: "nomer dana mu",
        destination_name: "nama dana mu",
    },
    
    // --- Qris Manual Setting ---
    manualQrisPhoto: "https://files.catbox.moe/ket5l4.jpg",
    
    // --- Vps Setting ---
    ApiDO1: "-",
    CostumPassVps: "fanoffc17", 
    // ganti api do lu
    hargaVPS: {
       low: {
        "2c2": 5000,
        "4c2": 5000,
        "8c4": 5000,
        "16c4": 5000,
        "16c8": 5000
      },
       medium: {
        "2c2": 10000,
        "4c2": 12000,
        "8c4": 15000,
        "16c4": 18000,
        "16c8": 20000
      },
       high: {
        "2c2": 10000,
        "4c2": 10000,
        "8c4": 10000,
        "16c4": 10000,
        "16c8": 10000
    }
  },
    // --- Fix Error Setting
    USER_LIMIT: 3,
    GEMINI_API_KEY: "AIzaSyB47adRUMkO-Yn_MOcOZBDV0PFIpzqKBy4",
    
    // --- PTERODACTYL PANEL ---
    panel: {
        domain: 'https://fanvsorangbaru.sano.biz.id', // domain public
        apikey: 'ptla_AWJWPlD1h4DIv0z0rJHpqgxWT8VVLceVDBgLDT0uUK2', // ptla panel
        pltc: 'ptlc_MXsvTvQOsZPXDXQWSceUGUf8Athbpz2o97NGek8wWg5', // ptlc panel
        nestId: 5,
        eggId: 15,
        locationId: 1,
        startup: "npm start",
        image: "ghcr.io/parkervcp/yolks:nodejs_24"
    },

    // --- HARGA PANEL ---
    hargaAdminPanel: 3500,
    hargaResellerPanel: 3000,
    hargaUbot: 2000,
    linkUbot: "-",
    linkResellerPanel: "-",
    hargaPanel: {
        unlimited: 17500,
        perGB: 500,  
    }
};